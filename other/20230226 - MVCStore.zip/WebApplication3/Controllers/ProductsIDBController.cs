﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication3.Data;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class ProductsIDBController : Controller
    {
        IStoreRepository _repository;
        public ProductsIDBController(IStoreRepository repository)
        {
            _repository= repository;
        }

        // GET: ProductsIDBController
        public ActionResult Index()
        {
            List<Product> products = _repository.Products.ToList();
            /*List<Product> products = new List<Product>()
            {
                new Product(){ProductID=1, Name="Product 1"},
                new Product(){ProductID=2, Name="Product 2"},
                new Product(){ProductID=3, Name="Product 3"},
            };*/

            return View(products);
        }

        // GET: ProductsIDBController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ProductsIDBController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ProductsIDBController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ProductsIDBController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ProductsIDBController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ProductsIDBController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ProductsIDBController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
