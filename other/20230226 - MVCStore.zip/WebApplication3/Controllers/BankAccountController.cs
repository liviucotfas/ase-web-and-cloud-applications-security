﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    [Authorize]
    public class BankAccountController : Controller
    {
        public IActionResult Transfer()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Transfer(TransferViewModel transfer)
        {
            if (ModelState.IsValid)
            {
                ViewBag.Message = $"You have transfered {transfer.Amount} euros to {transfer.DestinationAccount}.";
            }
            return View(transfer);
        }
    }
}
