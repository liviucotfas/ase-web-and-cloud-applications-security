﻿using WebApplication3.Models;

namespace WebApplication3.Data
{
    public class EFStoreRepository : IStoreRepository
    {
        ApplicationDbContext _context;

        public EFStoreRepository(ApplicationDbContext context) 
        {
            _context = context;
        }

        public IQueryable<Product> Products
        {
            get
            {
                return _context.Products;
            }
        }
    }
}
