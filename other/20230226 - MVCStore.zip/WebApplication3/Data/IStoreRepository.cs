﻿using WebApplication3.Models;

namespace WebApplication3.Data
{
    public interface IStoreRepository
    {
        IQueryable<Product> Products { get; }
    }
}
