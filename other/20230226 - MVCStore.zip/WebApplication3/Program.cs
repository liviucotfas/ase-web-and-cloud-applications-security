using Microsoft.AspNetCore.Connections;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using WebApplication3.Data;

namespace WebApplication3
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
                        
            builder.Services.AddControllersWithViews();
            var connectionString = builder.Configuration["ConnectionStrings:DefaultConnection"];
            builder.Services.AddDbContext<ApplicationDbContext>(
                x => x.UseSqlServer(connectionString));
            builder.Services.AddScoped<IStoreRepository, EFStoreRepository>();
            //builder.Services.AddDefaultIdentity<IdentityUser>(x=>x.SignIn.RequireConfirmedAccount = false)
            //.AddEntityFrameworkStores<ApplicationDbContext>();
            builder.Services.AddIdentity<IdentityUser, IdentityRole>()
                .AddRoleManager<RoleManager<IdentityRole>>()
                .AddDefaultUI()
                .AddEntityFrameworkStores<ApplicationDbContext>();

            var app = builder.Build();

          
            app.UseAuthentication();
            app.UseAuthorization();

            //app.MapGet("/", () => "Hello World!");
            //app.MapDefaultControllerRoute();
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Products}/{action=Index}/{id?}");

            //support for razer pages which are used by identity
            app.MapRazorPages();


            Task.Run(async () => await PopulateDBAsync(app));

            

            app.Run();
        }

        static async Task PopulateDBAsync(IApplicationBuilder app)
        {
            var serviceProvider = app.ApplicationServices.CreateScope().ServiceProvider;
            var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();

            var roleName = "admin";
            if(!await roleManager.RoleExistsAsync(roleName))
            {
                await roleManager.CreateAsync(new IdentityRole(roleName));
            }

            var adminUsername = "admin@gmail.com";

            var userManager = serviceProvider.GetRequiredService<UserManager<IdentityUser>>();

            IdentityUser admin = await userManager.FindByEmailAsync(adminUsername);
            if(admin == null)
            {
                admin = new IdentityUser
                {
                    UserName = adminUsername,
                    Email = adminUsername
                };
                await userManager.CreateAsync(admin, "Password1!");
                await userManager.AddToRoleAsync(admin, roleName);
            }
        }
    }
}