﻿using IronBankWeb.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace IronBankWeb.Controllers
{
    [Authorize]
    public class BankAccountController : Controller
    {
        public IActionResult Transfer()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Transfer(TransferViewModel viewModel)
        {
            if(ModelState.IsValid)
            {
                //we do the transfer
                TempData["message"] = $"You have transfered {viewModel.Amount} euros to {viewModel.DestinationAccount}";
            }
            return View(viewModel);
        }
    }
}
