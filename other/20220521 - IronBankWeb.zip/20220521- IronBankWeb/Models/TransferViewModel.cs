﻿namespace IronBankWeb.Models
{
    public class TransferViewModel
    {
        public string DestinationAccount { get; set; }
        public decimal Amount { get; set; }
    }
}
