﻿using Microsoft.AspNetCore.Mvc;
using MVCStore.Data;
using MVCStore.ViewModels;

namespace MVCStore.Controllers
{
    public class HomeController : Controller
    {
        public int PageSize = 1;

        private IStoreRepository repository;

        public HomeController(IStoreRepository repo)
        {
            repository = repo;
        }

        public IActionResult Index(int productPage = 1)
        {
            ViewBag.Title = "MVCStore";

            var products = repository.Products
                .OrderBy(x => x.ProductId)
                .Skip((productPage - 1) * PageSize)
                .Take(PageSize);

            var paginingInfo = new PagingInfoViewModel
            {
                CurrentPage = productPage,
                ItemsPerPage = PageSize,
                TotalItems = repository.Products.Count()
            };

            ProductsListViewModel viewModel = new ProductsListViewModel()
            {
                Products = products,
                PaginingInfo = paginingInfo
            };

            return View(viewModel);
        }
    }
}
