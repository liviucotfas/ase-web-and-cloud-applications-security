﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MVCStore.Data;
using MVCStore.Models;

namespace MVCStore.Controllers
{
    [Authorize]
    public class AdminController : Controller
    {
        private IStoreRepository repository;
        public AdminController(IStoreRepository repository)
        {
            this.repository = repository;
        }

        public IActionResult Index()
        {
            var products = repository.Products;
            return View(products);
        }

        [HttpGet]
        public IActionResult Edit(int productId)
        {
            var product = repository.Products.FirstOrDefault(p => p.ProductId == productId);
            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Product product)
        {
            if(ModelState.IsValid)
            {
                await repository.SaveProductAsync(product);
                TempData["message"] = "Product updated!";
                return RedirectToAction("Index");
            }
            else
            {
                return View(product);
            }
        }

        public IActionResult Create()
        {
            return View("Edit", new Product());
        }

        [HttpPost]
        [Authorize(Roles = "DeleteProductsRole")]
        public async Task<IActionResult> Delete(int productId)
        {
            Product product = await repository.DeleteProductAsync(productId);
            if (product != null)
            {
                TempData["message"] = $"{product.Name} was deleted";
            }

            return RedirectToAction("Index");
        }


        private void asfsafsdf()
        {

        }
    }
}
