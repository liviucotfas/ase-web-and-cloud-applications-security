﻿using Microsoft.EntityFrameworkCore;
using MVCStore.Models;

namespace MVCStore.Data
{
    public class EFStoreRepository : IStoreRepository
    {
        private ApplicationDbContext context;

        public EFStoreRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }

        public IQueryable<Product> Products {
            get { return context.Products; }
        }

        public async Task<Product> DeleteProductAsync(int productId)
        {
            Product? dbEntry = context.Products.FirstOrDefault(x => x.ProductId == productId);

            if(dbEntry != null)
            {
                context.Products.Remove(dbEntry);
                await context.SaveChangesAsync();
            }

            return dbEntry;
        }

        public async Task SaveProductAsync(Product product)
        {
            if (product.ProductId == 0)
            {
                context.Products.Add(product);
            }
            else
            {
                Product entity = context.Products.FirstOrDefault(x=>x.ProductId == product.ProductId);

                if(entity != null)
                {
                    entity.Name = product.Name;
                    entity.Decription = product.Decription;
                    entity.Price = product.Price;
                }
            }

            await context.SaveChangesAsync();

            
            //SQL Injection
            /*if(product.ProductId == 0)
            {
                string query = $"INSERT INTO Products(Name, Decription, Price) VALUES ('{product.Name}', '{product.Decription}', {product.Price})";

                context.Database.ExecuteSqlRaw(query, );
            }
            else
            {
                //TODO
            }*/
        }
    }
}
