﻿using Microsoft.EntityFrameworkCore;
using MVCStore.Models;

namespace MVCStore.Data
{
    public static class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            ApplicationDbContext context = app.ApplicationServices.CreateScope().ServiceProvider.GetRequiredService<ApplicationDbContext>();

            if (context.Database.GetPendingMigrations().Any())
            {
                context.Database.Migrate();
            }

            if (!context.Products.Any())
            {
                context.Products.AddRange(
                new Product
                {
                    Name = "Lifejacket",
                    Decription = "Protective and fashionable",
                    Price = 48.95m
                });
                context.SaveChanges();
            }
        }
    }
}
