using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

using Microsoft.EntityFrameworkCore;
using MVCStore.Data;

namespace MVCStore
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddControllersWithViews();

            string connectionString = builder.Configuration["ConnectionStrings:DefaultConnection"];
            builder.Services.AddDbContext<ApplicationDbContext>(opts => opts.UseSqlServer(connectionString));

            builder.Services.AddIdentity<IdentityUser, IdentityRole>()
                .AddRoleManager<RoleManager<IdentityRole>>()
                .AddDefaultUI()
                .AddEntityFrameworkStores<ApplicationDbContext>();

            builder.Services.AddScoped<IStoreRepository, EFStoreRepository>();

            //Configurations
            var app = builder.Build();
            app.UseStaticFiles();

            app.UseAuthentication();
            app.UseAuthorization();

            app.MapControllerRoute(
                "pagination",
                "Products/Page{productPage}",
                new { Controller = "Home", action = "Index" });
            app.MapDefaultControllerRoute();
            //app.MapGet("/", () => "Hello World!");
            app.MapRazorPages();

            SeedData.EnsurePopulated(app);
            Task.Run(async () =>
                await SeedDataIdentity.EnsurePopulatedAsync(app)
            ).Wait();

            app.Run();
        }
    }
}