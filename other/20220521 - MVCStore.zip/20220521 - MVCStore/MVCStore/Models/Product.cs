﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVCStore.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        [Required(ErrorMessage ="Please enter a name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please enter a description")]
        public string Decription { get; set; }
        [Required(ErrorMessage = "Please enter a price")]
        [Range(0.01,double.MaxValue, ErrorMessage = "Please enter a positive price")]
        [Column(TypeName = "decimal(8, 2)")]
        public decimal Price { get; set; }

    }
}
