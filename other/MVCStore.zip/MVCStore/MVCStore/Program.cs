using Microsoft.EntityFrameworkCore;
using MVCStore.Data;

namespace MVCStore
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            
            builder.Services.AddControllersWithViews();

            string connectionString = builder.Configuration["ConnectionStrings:DefaultConnection"];
            builder.Services.AddDbContext<ApplicationDbContext>(opts => opts.UseSqlServer(connectionString));

            builder.Services.AddScoped<IStoreRepository, EFStoreRepository>();

            //Configurations
            var app = builder.Build();
            app.UseStaticFiles();
            app.MapDefaultControllerRoute();
            //app.MapGet("/", () => "Hello World!");

            SeedData.EnsurePopulated(app);

            app.Run();
        }
    }
}