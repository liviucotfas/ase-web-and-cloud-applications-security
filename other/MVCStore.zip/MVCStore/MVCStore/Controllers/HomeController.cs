﻿using Microsoft.AspNetCore.Mvc;

namespace MVCStore.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Title = "MVCStore";
            return View();
        }
    }
}
