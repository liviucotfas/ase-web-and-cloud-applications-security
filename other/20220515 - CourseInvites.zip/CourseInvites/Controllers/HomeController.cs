﻿using CourseInvites.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CourseInvites.Controllers
{
    public class HomeController : Controller
    {
        public HomeController()
        {
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult RsvpForm()
        {
            return View();
        }

        [HttpPost]
        public IActionResult RsvpForm(GuestResponse guestResponse)
        {
            if (ModelState.IsValid)
            {
                Repository.AddResponse(guestResponse);
                return View("Thanks", guestResponse);
                //return RedirectToAction("Thanks");
            }
            else
            {
                return View();
            }
        }

        public IActionResult ListResponses()
        {
            IEnumerable<GuestResponse> people = Repository.Response.Where(x => x.WillAttend == true);

            return View(people);
        }
    }
}