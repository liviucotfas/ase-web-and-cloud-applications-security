﻿using HelloWorld.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace HelloWorld.Controllers
{
    public class HomeController : Controller
    {
        /*public string Index()
        {
            return "Hello World!";
        }*/

        public IActionResult Index()
        {
            int hour = DateTime.Now.Hour;

            string message = null;
            if (hour < 12)
                message = "Good Morning";
            else
                message = "Good Afternoon";

            //ViewBag.Greeting = message;
            ViewData["Greeting"] = message;

            return View();
        }
    }
}